package org.example.springboot.enums;

public enum City {

    Moscow,
    Crimea,
    Cairo

}
