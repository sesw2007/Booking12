package org.example.springboot.enums;

public enum Country {
    Russia,
    China,
    Egypt,
    Turkey;

}
